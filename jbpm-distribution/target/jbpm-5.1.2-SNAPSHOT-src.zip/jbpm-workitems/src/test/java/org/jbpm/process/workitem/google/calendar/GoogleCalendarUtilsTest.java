package org.jbpm.process.workitem.google.calendar;

import junit.framework.TestCase;

public class GoogleCalendarUtilsTest extends TestCase {
	
	private static final String USERNAME = "drools.demo@gmail.com";
	private static final String PASSWORD = "pa$$word";
	
	public void testEmpty() {
	}

	public void testCalendar() throws Exception {
//		List<String> calendars =
//			GoogleCalendarUtils.getCalendars(USERNAME, PASSWORD);
//		for (String calendar: calendars) {
//			System.out.println(calendar);
//		}
//		assertEquals(1, calendars.size());
//		assertEquals("drools.demo@gmail.com", calendars.get(0));
	}
	
	public void TODOtestCreateCalendarEntry() throws Exception {
//		GoogleCalendarUtils.insertEntry(
//			USERNAME, PASSWORD, 
//			"New Drools Meeting",
//			"Showing the new features of Drools",
//			DateTime.now().toString(),
//			DateTime.now().toString());
//		System.out.println(DateTime.now().toString());
//		List<CalendarEventEntry> entries = 
//			GoogleCalendarUtils.getEntries(USERNAME, PASSWORD, "Drools");
//		for (CalendarEventEntry entry: entries) {
//			System.out.println(entry.getTitle().getPlainText());
//		}
//		assertEquals(1, entries.size());
//		entries.get(0).delete();
	}
	
}
