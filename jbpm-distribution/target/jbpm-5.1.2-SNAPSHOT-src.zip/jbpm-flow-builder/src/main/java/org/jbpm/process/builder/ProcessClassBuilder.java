package org.jbpm.process.builder;


public interface ProcessClassBuilder {

    public String  buildRule(final ProcessBuildContext context);

}